/* Copyright © 2014, Oracle and/or its affiliates. All rights reserved. */
package doordata;

import com.oracle.deviceaccess.PeripheralConfigInvalidException;
import com.oracle.deviceaccess.PeripheralExistsException;
import com.oracle.deviceaccess.PeripheralNotFoundException;
import com.oracle.deviceaccess.PeripheralTypeNotSupportedException;
import java.io.IOException;
import javax.microedition.midlet.MIDlet;

/**
 * The DoorSensorMIDlet detects changes in the door switch state. Note that this MIDlet
 * uses different logic from the rest of the course - the door is in a closed state when
 * the pushbutton is not pressed, and opened when the switch is pressed.
 * 
 * @author Tom McGinn
 */
public class DoorSensorMIDlet extends MIDlet {

    private DoorSensorTask doorSensorTask;
    /**
     * doorOpenDelay is the number of seconds to wait before a door event is
     * triggered. This delay prevents spurious changes - ie: when a door is
     * bouncing around or not completely closed, but not open either.
     */
    private int doorOpenDelay = 5;

    @Override
    public void startApp() {

        // If a property is defined - use that as the delay
        try {
            String delayProp = getAppProperty("DoorOpenDelay");
            if (delayProp != null) {
                doorOpenDelay = Integer.parseInt(delayProp);
            }
        } catch (NumberFormatException ex) {
            System.out.println("NumberFormatException: DoorOpenDelay: " + ex);
        }

        // Create an instance of the door sensor task
        doorSensorTask = new DoorSensorTask(0, 17);

        try {
            doorSensorTask.start(doorOpenDelay);
        } catch (PeripheralTypeNotSupportedException | PeripheralNotFoundException | PeripheralConfigInvalidException | PeripheralExistsException ex) {
            System.out.println("PeripheralException: " + ex.getMessage());
            notifyDestroyed();
        } catch (IOException ex) {
            System.out.println("IOException: " + ex);
            notifyDestroyed();
        }
    }

    /**
     * Imlet lifecycle termination method
     *
     * @param unconditional If the imlet should be terminated whatever
     */
    @Override
    public void destroyApp(boolean unconditional) {
        try {
            doorSensorTask.close();
        } catch (IOException ex) {
            System.out.println("IOException closing DoorSensor: " + ex);
        }
    }

    /**
     * Imlet lifecycle pause method
     */
    @Override
    public void pauseApp() {
    }

}
